$(document).ready(function () {  

    $("#cambiarpass").click(function () {
        $('#form_cambio_pass').toggle(function () { });
    });    

});
