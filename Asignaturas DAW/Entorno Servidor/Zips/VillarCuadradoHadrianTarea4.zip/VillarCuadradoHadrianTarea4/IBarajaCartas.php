<?php 
interface IBarajaCartas{
    public function compareTo(Baraja $b1, Baraja $b2);
}
