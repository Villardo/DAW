<?php
$db = mysqli_connect("localhost", "root", "", "recetas");
$db->set_charset("utf8");
