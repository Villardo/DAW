package cartas;

public class BarajaEspanhola extends Baraja {

    protected boolean incluir8y9 = false;

    public void crearBaraja() {
    }

    public boolean getIncluir8y9() {
        return this.incluir8y9;
    }

    public void setIncluir8y9(boolean incluir8y9) {
        this.incluir8y9 = incluir8y9;
    }
    
    public void compareTo(Baraja baraja) {
        if (baraja instanceof BarajaEspanhola) {
            System.out.println("Las dos barajas son españolas");
        }
        else
        {
            System.out.println("Las barajas son diferentes");
        }
    }    

}
