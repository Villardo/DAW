package cartas;

public class Carta {
    private int numero;
    private int palo;
    
    public Carta(int numero, int palo) {
        this.numero = numero;
        this.palo = palo;
    }

    public int getNumero() {
        return numero;
    }

    public int getPalo() {
        return palo;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public void setPalo(int palo) {
        this.palo = palo;
    }
    
    @Override
    public String toString(){
        return "La carta es el " + this.numero + " de " + this.palo + "<br>";
    }
    
}
