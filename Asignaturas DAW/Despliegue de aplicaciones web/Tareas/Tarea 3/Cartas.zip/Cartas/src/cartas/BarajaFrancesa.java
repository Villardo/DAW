package cartas;

public class BarajaFrancesa extends Baraja {

    public void crearBaraja() {
    }

    public void compareTo(Baraja baraja) {
        if (baraja instanceof BarajaFrancesa) {
            System.out.println("Las dos barajas son francesas");
        } else {
            System.out.println("Las barajas son diferentes");
        }
    }

}
