package cartas;

interface BarajaCartas {
    public void compareTo(Baraja $baraja);
    
}
