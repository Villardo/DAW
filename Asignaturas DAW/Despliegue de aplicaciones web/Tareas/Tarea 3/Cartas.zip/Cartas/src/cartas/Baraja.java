package cartas;

public abstract class Baraja implements BarajaCartas {

    protected Carta[] cartas;
    protected int posSiguienteCarta = 0;
    protected static int NUM_CARTAS = 40;

    public Carta[] getCartas() {
        return cartas;
    }

    public int getPosSiguienteCarta() {
        return posSiguienteCarta;
    }

    public static int getNUM_CARTAS() {
        return NUM_CARTAS;
    }

    public void setCartas(Carta[] cartas) {
        this.cartas = cartas;
    }

    public void setPosSiguienteCarta(int posSiguienteCarta) {
        this.posSiguienteCarta = posSiguienteCarta;
    }

    public static void setNUM_CARTAS(int NUM_CARTAS) {
        NUM_CARTAS = NUM_CARTAS;
    }

    protected void addCarta(Carta unaCarta) {
        this.cartas[cartas.length - 1] = unaCarta;
    }

    abstract void crearBaraja();

    public void barajar() {
    }

    public void siguienteCarta() {
    }

    public void cartasDisponibles() {
    }

    public void repartirCartas(int cartasPedidas) {
    }

    public void cartasRepartidas() {
    }

    public void mostrarBaraja() {
    }

}
