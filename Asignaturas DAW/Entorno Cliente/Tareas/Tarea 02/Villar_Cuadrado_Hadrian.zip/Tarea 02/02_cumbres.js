let cumbres = [
    {
        nombre: "Kilimanjaro",
        altura: 5895,
        pais: "Tanzania"
    },
    {
        nombre: "Teide",
        altura: 3718,
        pais: "España"
    },
    {
        nombre: "Everest",
        altura: 8848,
        pais: "Nepal"
    }
];
