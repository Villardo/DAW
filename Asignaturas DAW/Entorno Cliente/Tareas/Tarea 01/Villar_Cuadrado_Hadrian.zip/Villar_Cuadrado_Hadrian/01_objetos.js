var movies = {
    "Finding Nemo": {
        releaseDate: 2003,
        duration: 100,
        actors: ["Albert Brooks", "Ellen DeGeneres", "Alexander Gould"],
        format: "DVD"

    },
    "Star Wars: Episode VI - Return of the Jedi": {
        releaseDate: 1983,
        duration: 134,
        actors: ["Mark Hamill", "Harrison Ford", "Carrie Fisher"],
        format: "DVD"
    },
    "Harry Potter and the Goblet of Fire": {
        releaseDate: 2005,
        duration: 157,
        actors: ["Daniel Radcliffe", "Emma Watson", "Rupert Grint"],
        format: "Blu-ray"
    },
    "Indiana Jones and the Last Crusade": {
        releaseDate: 1986,
        duration: 128,
        actors: ["Harrison Ford", "Alison Doody", "Sean Connery"],
        format: "DVD"
    }
};

var myObject = {
    "name": "An object",
    "some array": [7, 9, { purpose: "learning", number: 123 }, 3.3],
    "random animal": "Cat"
};